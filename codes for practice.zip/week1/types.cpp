#include <iostream>

using namespace std;
int main()
{
    int i=0;
    long l=0;
    cout << "Integer size:" << sizeof(i) << endl;
    cout << "Long size:"  << sizeof(l) << endl;

    bool b;
    b = true;
    cout<< "bool b = true: "<< b<< endl;
    b = false;
    cout<< "bool b = false: "<< b<< endl;
    b += 22;
    cout<< "b+=22: "<< b<< endl;
    i = false + 22;
    cout<< "i=false+22: "<< i<< endl;
    i = true + 22;
    cout<< "i=true+22: "<< i<< endl;

    char c = 100;

    cout << (int)c << "\n";
    c += 100;
    cout << (int)c << "\n";

    c += 100;
    cout << (int)c  << "\n";

}
