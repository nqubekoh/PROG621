/**
/* input.cpp
/*
/* Demonstrates command line input and output
/* Converts inches to centimeters
**/

#include <iostream>
using namespace std;

const double INCHES_TO_CM = 2.54;
// A constant can be defined anywhere

int main()
{
    double length=0;

    cout << "Enter the length in inches: ";
    cin >> length;
    cout << "The length in centimeters is: " << length*INCHES_TO_CM;

    return 0;
}
