
//----- hello.cpp ----------------------------------
//Your first C++ Program illustrating stream output.
//-------------------------------------------------
#include <iostream>
/* this is a begin-end comment*/
int main()
{
    std::cout << "Hello from C++.\n";
    return 0;
}
