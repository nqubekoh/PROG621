#include <iostream>
#include <cmath>
using namespace std;

  //fields
 double a, b, c;

   //3  methods
 double getRoot1(double a, double b, double c);
 double getRoot2(double a, double b, double c);
 int getNumRoots();
 int getNumRoots(){






 }

double getRoot1(double a, double b, double c){

 return double  (-b+  (sqrt(pow(b,2) - (4*a*c) ))   )/2*a;

 }


 double getRoot2(double a, double b, double c){


 return (b+(sqrt(pow(b,2)-(4*a*c))))/2*a;

 }

double x =sqrt (4.0);

int main()
{


cout << "please enter the value for a\n";
cin >> a;
cout << "please enter the value for b\n";
cin >> b;
cout << "please enter the value for c\n";
cin >> c;

cout << " function has\n ";
cout<< "Roots are:   "<<getRoot1(a,b,c) <<"   and  :" <<getRoot2(a,b,c);

}


