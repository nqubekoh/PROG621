
//----- hello.cpp ----------------------------------
//Your first C++ Program illustrating stream output.
//-------------------------------------------------
#include <iostream>
using namespace std;
/* this is a begin-end comment*/
int main()
{
    cout << "Hello from C++.\n";
    //return 0;
}

