#include <iostream>

using namespace std;

double add(double& a, double& b);
int add(int& a, int& b);
//int add(int a , int b );

int main(){
    int a=1;
    int b=3;

    double c=4;
    double d=5;
    cout << "a: " << a << " + b: " << b << " = " << add(a,b) << "\n";

    cout << "c: " << c << " + d: " << d << " = " << add(c,d) << "\n";
}


int add(int& a, int& b){
    //a =5;
    return a+b;
}


double add(double& a, double& b){
    return a+b;
}

/*int add(int a, int b){
    a =5;
    return a+b;
}*/
