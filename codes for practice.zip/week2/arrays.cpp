#include <iostream>
using namespace std;

// function declaration:

double getAverage(int arr[], int size);

int main ()
{
    // an int array initialised with 5 elements.
    int arr[5] = {1000, 2, 3, 17, 50};
    double avg;

    // pass pointer to the array as an argument.
    avg = getAverage( arr, 5 ) ;

    // output the returned value
    cout << "Average value is: " << avg << endl;

    // we can also pass a pointer to the first element
    avg = getAverage(&arr[0], 5 ) ;
    cout << "Average value is: " << avg << endl;

    cout << arr << endl;
    cout << &arr[0] << endl;

    int *intPtr;
    intPtr = &arr[0];

    cout << intPtr << endl;

    cout << *intPtr << endl; // print the first element
    intPtr++;
    cout << *intPtr << endl; // print the second element

     intPtr++;
    cout << *intPtr << endl;
    /*int a=0;
    cout << "Size of integer on this machine: " << sizeof(a) << " bytes" << endl;
    intPtr = &arr[0];
    for (int i=0;i<5; i++){
        cout << "Index: " << i << " memory addr hex: " << intPtr
             << " memory addr int: " << (int)intPtr << " value: " << *intPtr << endl;
        intPtr++;
    }*/
}

double getAverage(int arr[], int size)
{
    int    i, sum = 0;
    double avg;

    for (i = 0; i < size; ++i)
    {
        sum += arr[i];
    }

    avg = double(sum) / size;

    return avg;
}


