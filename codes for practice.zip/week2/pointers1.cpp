#include <iostream>

using namespace std;

int main(){
    int i; // allocate memory (4 bytes) for an integer

    cout << "Memory address allocated to i: " << &i << "\n";
    cout << "Initial value at memory allocated to i: " << i << "\n";

    i = 10; // assign the value

    int* pInt;  // declare an integer pointer variable,
                // i.e. a variable that can store the address of an integer variable
    cout << "Value of pInt: " << pInt << "\n";
    pInt=NULL; // set it to the null address
    cout << "Address assigned to pInt: " << pInt << "\n";

    cout << "Assigning pInt the address of i \n";
    pInt = &i; // set it to the address of i
    cout << "Value of pInt: " << pInt << "\n";

    // derefence pInt, i.e. get the value stored at address pInt
    cout << "Value stored at address: "  << pInt << " is: " << *pInt << "\n";

    int x = 20;
    void *ptr = &x;
    cout << *(static_cast<int*>(ptr))<< endl; // C++ cast statement static_cast<type>
    cout << *((int*)(ptr)); // cast to int pointer and then dereference

}
