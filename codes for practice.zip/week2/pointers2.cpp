#include <iostream>

using namespace std;

int add(int a, int b);
int add(int* a, int* b);

int main(){
    int a=3;
    int b=5;

    cout << "a: " << a << " + b: " << b << " = " << add(a,b) << "\n";

    cout << "a: " << a << " + b: " << b << " = " << add(&a,&b) << "\n";
}

int add(int a, int b){
    a=10;
    return a+b;
}

/*int add(int* a, int* b){

    int x=*a;
    int y=*b;
    *a = 8;
    return x+y;
    //return *a+*b;  // could also add in a single line
}*/

int add(int &a, int &b){

    return a+b;
}
