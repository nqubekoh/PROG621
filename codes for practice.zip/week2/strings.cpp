#include<iostream>

using namespace std;

int main(){

/*
    //char cstr[10] = "qwerty"; // stored as q w e r t y \0
    char cstr[] = "qwe\0rty";

    char* pStr1;

    cout << *cstr << "[END OF STRING]\n";
    for(int i=0; i<10; i++)
        cout << i << ": " << cstr[i] << "\n";
*/

/*
    string s1, s2;
    cout << "Enter you name: ";
    //cin >> s1; // reads the first word until the first white space. You would need another cin call to get the next word
    //cin >> s2;
    cin >> s1 >> s2; // same as for multiple output using cout
    cout << "Hello " << s1+ " " + s2+"\n";


*/

    string line;
    cout << "Enter you name: ";
    getline(cin, line); // retreives an entire line from the console input stream object
    cout << "Hello " << line+"\n";

    int length=line.length();
    cout << " length: " << length << endl;
    for(int i=0; i<line.length(); i++)
        cout << i << ":" <<line.at(i) << "\n";
    cout << endl;

    line.at(1) = 'i'; // Set the second element to the char i
    // char elements in the string can be accessed using the square brackets, e.g.
    for(int i=0; i<line.length(); i++)
        cout << i << ":" <<line[i] << "\n";

    cout << "[END OF STRING]\n";


}
