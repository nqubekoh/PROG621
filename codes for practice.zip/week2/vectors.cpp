#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main(){

    vector<int> v;

    cout << "Enter a list of postive numbers <Enter -1 to complete> \n";
    int num;
    cin >> num;
    while(num!=-1){
        v.push_back(num);
        cout << "added " << num;
        cout << " v.size() = " << v.size() << endl;
        cin >> num;
    }

    cout << "Unsorted vector " << endl;
    for(int i=0; i<v.size(); i++)
        cout << v[i] << " ";

    sort(v.begin(), v.end());
    cout << "Sorted vector " << endl;
    for(int i=0; i<v.size(); i++)
        cout << v[i] << " ";



    // allocate space for and insert the following elements
    v.push_back(5);
    v.push_back(-1000);
    v.push_back(99);
    v.push_back(1);

    cout << v.size();

}
